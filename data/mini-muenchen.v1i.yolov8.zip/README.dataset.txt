# mini-muenchen > 2024-05-25 2:40pm
https://universe.roboflow.com/itm-innovationlab/mini-muenchen

Provided by a Roboflow user
License: MIT

